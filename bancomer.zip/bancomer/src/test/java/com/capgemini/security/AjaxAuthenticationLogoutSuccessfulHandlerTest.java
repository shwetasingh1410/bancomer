package com.capgemini.security;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.junit.Test;
import com.capgemini.security.AjaxLogoutSuccessHandler;

public class AjaxAuthenticationLogoutSuccessfulHandlerTest {

	@Test
	public void testonLogoutSuccess() throws IOException, ServletException{
		AjaxLogoutSuccessHandler ajaxLogoutSuccessHandler=new  AjaxLogoutSuccessHandler();
		HttpServletRequest request = mock(HttpServletRequest.class); 
		HttpServletResponse response = mock(HttpServletResponse.class);
		response.setStatus(0, "dfgh");
		ajaxLogoutSuccessHandler.onLogoutSuccess(request, response, null);

	}
}
