package com.capgemini.security;

import org.junit.Test;
import com.capgemini.security.UserNotActivatedException;

public class UserNotActivatedExceptionTest {

	@Test
	public void testUserNotActivatedException() {
		new UserNotActivatedException("message");              
		new UserNotActivatedException("message",null);           
	}

}
