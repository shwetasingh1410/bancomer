package com.capgemini.security;

import org.junit.Test;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import com.capgemini.security.AuthoritiesConstants;
import com.capgemini.security.SecurityUtils;
import java.util.ArrayList;
import java.util.Collection;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import static org.assertj.core.api.Assertions.assertThat;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.User;

/**
 * Test class for the SecurityUtils utility class.
 *
 * @see SecurityUtils
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SecurityUtilsUnitTest {

	@Test
	public void authenticationIsNull(){

		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(null);
		String login = SecurityUtils.getCurrentUserLogin();
		assertThat(login).isEqualTo(null);

	}

	@Test
	public void testCurrentUserInRole()
	{
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		String login = SecurityUtils.getCurrentUserLogin();
		assertThat(login).isEqualTo("admin");
		boolean isCurrentUserInRole = SecurityUtils.isCurrentUserInRole(login);
		assertThat(isCurrentUserInRole).isFalse();

	}
	@Test
	public void testgetCurrentUserLogin() {
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		String login = SecurityUtils.getCurrentUserLogin();
		assertThat(login).isEqualTo("admin");
	}

	@Test
	public void testIsAuthenticated() {
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		boolean isAuthenticated = SecurityUtils.isAuthenticated();
		assertThat(isAuthenticated).isTrue();
	}

	@Test
	public void testAnonymousIsNotAuthenticated() {
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		Collection<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority(AuthoritiesConstants.ANONYMOUS));
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("anonymous", "anonymous", authorities));
		SecurityContextHolder.setContext(securityContext);
		boolean isAuthenticated = SecurityUtils.isAuthenticated();
		assertThat(isAuthenticated).isFalse();
	}
	@Test
	public void testCurrentUserInRoleForUserDetailsInstance()
	{
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		//Collection<GrantedAuthority>
		UserDetails us=new User("admin", "admin", new ArrayList<GrantedAuthority>());
		Authentication a=new UsernamePasswordAuthenticationToken(us, us);
		securityContext.setAuthentication(a);
		SecurityContextHolder.setContext(securityContext);
		String login = SecurityUtils.getCurrentUserLogin();
		assertThat(login).isEqualTo("admin");
		boolean isCurrentUserInRole = SecurityUtils.isCurrentUserInRole(login);
		assertThat(isCurrentUserInRole).isFalse();

	}
	
	@Test
	public void testAnonymousIsNotAuthenticatedForNullAuthorities  () {
		//authorities.add(new SimpleGrantedAuthority(AuthoritiesConstants.ANONYMOUS));
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		Collection<GrantedAuthority> authorities = new ArrayList<>();
		authorities.add(new SimpleGrantedAuthority(AuthoritiesConstants.USER));
		authorities.add(new SimpleGrantedAuthority(AuthoritiesConstants.ADMIN));
		
		
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("user", "user", authorities));
		SecurityContextHolder.setContext(securityContext);
		boolean isAuthenticated = SecurityUtils.isAuthenticated();
		assertThat(isAuthenticated).isTrue();
	}


}
