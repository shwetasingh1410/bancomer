package com.capgemini.security;

import static org.mockito.Mockito.mock;
import org.junit.Test;
import com.capgemini.security.Http401UnauthorizedEntryPoint;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Http401UnauthorisedEntryPointTest {

	@Test
	public void testcommence() throws Exception
	{
		Http401UnauthorizedEntryPoint http401UnauthorizedEntryPoint=new Http401UnauthorizedEntryPoint();
		HttpServletRequest request = mock(HttpServletRequest.class); 
		HttpServletResponse response = mock(HttpServletResponse.class);
		response.sendError(0, "access denied");
		http401UnauthorizedEntryPoint.commence(request, response, null);
	}
}
