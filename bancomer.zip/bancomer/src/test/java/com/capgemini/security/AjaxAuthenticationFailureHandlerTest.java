package com.capgemini.security;

import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;

import org.junit.Test;
import com.capgemini.security.AjaxAuthenticationFailureHandler;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AjaxAuthenticationFailureHandlerTest {

	@Test
	public void AjaxAuthenticationFailureHandler() throws Exception
	{
		AjaxAuthenticationFailureHandler ajaxAuthenticationFailureHandler=new AjaxAuthenticationFailureHandler();
		HttpServletRequest request = mock(HttpServletRequest.class); 
		HttpServletResponse response = mock(HttpServletResponse.class);
		response.sendError(0,"sdf");
		ajaxAuthenticationFailureHandler.onAuthenticationFailure(request, response, null);
	}
}

