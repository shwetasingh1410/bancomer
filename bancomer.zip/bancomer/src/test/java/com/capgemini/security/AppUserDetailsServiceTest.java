package com.capgemini.security;

import static org.junit.Assert.*;
import javax.inject.Inject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.BbvaApp;
import com.capgemini.domain.User;
import com.capgemini.repository.UserRepository;
import com.capgemini.service.UserService;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = BbvaApp.class)
@WebAppConfiguration
public class AppUserDetailsServiceTest {

	@Inject
	private UserRepository userRepository;
	@Inject
	org.springframework.security.core.userdetails.UserDetailsService uds;
	@Inject
	private UserService userService;

	@Test(expected =org.springframework.security.core.userdetails.UsernameNotFoundException.class)
	@Transactional
	public void testLoadUserByUsernameForInvalidUserName(){
		UserDetails ud=uds.loadUserByUsername("userS");
		assertTrue(ud.getUsername()=="");
	}

	@Test(expected =UserNotActivatedException.class)
	@Transactional
	public void testLoadUserByUsernameForNotActivatedUser(){
		User user = userService.createUserInformation("svkda", "johndoe", "John", "Doe", "john.doe@localhost", "en-US");
		UserDetails ud=uds.loadUserByUsername("svkda");
		assertTrue(ud.getUsername()=="svkda");
		userRepository.delete(user);
	}
	
	@Test
	@Transactional
	public void testLoadUserByUsernameSuccessful(){
		UserDetails ud=uds.loadUserByUsername("user");
		assertTrue(ud.getUsername()=="user");
	}
}

