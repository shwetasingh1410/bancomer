package com.capgemini.web.rest.dto;

import org.junit.Test;

public class LoggerDTOTest {

	@Test
	public void testToString() {

		LoggerDTO loggerdto= new LoggerDTO();
		loggerdto.setName("john");
		loggerdto.setLevel("1");
		loggerdto.toString();

	}
}
