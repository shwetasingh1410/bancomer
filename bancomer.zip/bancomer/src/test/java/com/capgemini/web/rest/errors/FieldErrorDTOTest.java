package com.capgemini.web.rest.errors;

import static org.junit.Assert.*;
import org.junit.Test;
import com.capgemini.web.rest.errors.FieldErrorDTO;

public class FieldErrorDTOTest {

	@Test
	public void testgetObjectName()
	{
		FieldErrorDTO fieldErrorDTO=new FieldErrorDTO("dto", "field", "message");
		assertEquals("dto",fieldErrorDTO.getObjectName());     
	}

	@Test
	public void testGetField()
	{
		FieldErrorDTO fieldErrorDTO=new FieldErrorDTO("dto", "field", "message");
		assertEquals("field",fieldErrorDTO.getField());

	}

	@Test
	public void testGetMessage()
	{
		FieldErrorDTO fieldErrorDTO=new FieldErrorDTO("dto", "field", "message");
		assertEquals("message",fieldErrorDTO.getMessage());

	}
}
