package com.capgemini.web.rest;
import com.capgemini.BbvaApp;
import com.capgemini.config.JHipsterProperties;
import com.capgemini.service.UserService;
import com.capgemini.web.rest.ProfileInfoResource;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.core.env.Environment;
import javax.inject.Inject;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the ProfileResourceREST controller.
 *
 * @see UserService
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = BbvaApp.class)
@WebAppConfiguration
@IntegrationTest
public class ProfileInfoResourceIntTest {

	@Inject
	Environment env;

	@Inject
	@Mock
	private JHipsterProperties jHipsterProperties;
	private MockMvc restUserMockMvc;

	@Before
	public void setup()
	{
		ProfileInfoResource profileinfores= new ProfileInfoResource();
		ReflectionTestUtils.setField(profileinfores, "env", env);
		ReflectionTestUtils.setField(profileinfores, "jHipsterProperties", jHipsterProperties);
		this.restUserMockMvc = MockMvcBuilders.standaloneSetup(profileinfores).build();
	}

	@Test
	public void testGetActiveProfiles() throws Exception {
		
		String profile[]={"dev"};
		jHipsterProperties.getRibbon().setDisplayOnActiveProfiles(profile);
		restUserMockMvc.perform(get("/api/profile-info")
				.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk());
        
	}
	
	@Test
	public void testActiveProfilesForNullRibbonValue() throws Exception
	{
String profile[]=null;
		jHipsterProperties.getRibbon().setDisplayOnActiveProfiles(profile);
				restUserMockMvc.perform(get("/api/profile-info")
				.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(content().contentType("application/json"));
		
	}

}
