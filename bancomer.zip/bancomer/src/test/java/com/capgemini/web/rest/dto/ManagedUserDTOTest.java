package com.capgemini.web.rest.dto;

import static org.junit.Assert.*;
import java.time.ZonedDateTime;

import org.junit.Assert;
import org.junit.Test;
import com.capgemini.web.rest.dto.ManagedUserDTO;

public class ManagedUserDTOTest {

	@Test
	public void setId()
	{

		ManagedUserDTO managedUserDTO=new ManagedUserDTO();
		managedUserDTO.setId((long)1234);
		assertTrue(managedUserDTO.getId() == (long)1234);
	}

	@Test
	public void setCreatedDate()
	{
		ManagedUserDTO managedUserDTO=new ManagedUserDTO();
		ZonedDateTime dateTime = ZonedDateTime.parse("2007-12-03T10:15:30+01:00[Europe/Paris]");
		managedUserDTO.setCreatedDate(dateTime);
		assertTrue(managedUserDTO.getCreatedDate() == dateTime); 


	}

	@Test
	public void setLastModifiedBy()
	{
		ManagedUserDTO managedUserDTO=new ManagedUserDTO();
		managedUserDTO.setLastModifiedBy("Kaustubh");
		assertTrue(managedUserDTO.getLastModifiedBy().equals("Kaustubh"));
	}

	@Test
	public void setLastModifiedDate()
	{
		ManagedUserDTO managedUserDTO=new ManagedUserDTO();
		ZonedDateTime dateTime = ZonedDateTime.parse("2007-12-03T10:15:30+01:00[Europe/Paris]");
		managedUserDTO.setLastModifiedDate(dateTime);
		assertTrue(managedUserDTO.getLastModifiedDate()==dateTime);
	}

	@Test
	public void testToString()
	{
		ManagedUserDTO managedUserDTO=new ManagedUserDTO();
		Assert.assertEquals("ManagedUserDTO{id=null, createdDate=null, lastModifiedBy=\'null\', lastModifiedDate=null} UserDTO{login=\'null\', firstName=\'null\', lastName=\'null\', email=\'null\', activated=false, langKey=\'null\', authorities=null}",managedUserDTO.toString());
	} 


}
