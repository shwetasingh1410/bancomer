package com.capgemini.web.rest.errors;

import static org.junit.Assert.*;
import org.junit.Test;
import com.capgemini.web.rest.errors.ErrorDTO;

public class ErrorDTOTest {

	ErrorDTO edto1=new ErrorDTO("message");
	ErrorDTO edto2=new ErrorDTO("message","description");
	ErrorDTO edto3=new ErrorDTO("message","description",null);

	@Test
	public void testGetMessage()
	{
		ErrorDTO errorDTO=new ErrorDTO("");
		assertEquals("",errorDTO.getMessage());

	}

	@Test
	public void testGetDescription()
	{
		ErrorDTO errorDTO=new ErrorDTO("");
		assertEquals(null,errorDTO.getDescription());

	}

	@Test
	public void  testGetFieldErrors()
	{
		ErrorDTO errorDTO=new ErrorDTO("");
		assertEquals(null,errorDTO.getFieldErrors());
	}

	@Test
	public void testAdd()
	{
		ErrorDTO errorDTO=new ErrorDTO("");
		errorDTO.add("objectName","field","message");
	}
} 
