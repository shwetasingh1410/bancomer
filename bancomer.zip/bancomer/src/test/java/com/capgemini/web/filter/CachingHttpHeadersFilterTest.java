package com.capgemini.web.filter;

import java.io.IOException;
import javax.inject.Inject;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockServletContext;
import com.capgemini.config.JHipsterProperties;
import com.capgemini.web.filter.CachingHttpHeadersFilter;


public class CachingHttpHeadersFilterTest {

	@Inject
	private JHipsterProperties jHipsterProperties;


	@Test
	public void testdoFilter() throws IOException, ServletException {
		MockServletContext servletContext = new MockServletContext();
		MockHttpServletRequest request = new MockHttpServletRequest(servletContext);
		MockHttpServletResponse response = new MockHttpServletResponse();
		FilterChain chain = Mockito.mock(FilterChain.class);
		request.setContextPath("/private/");
		CachingHttpHeadersFilter cachingHttpHeadersFilter = new CachingHttpHeadersFilter(jHipsterProperties);
		cachingHttpHeadersFilter.doFilter(request, response, chain);
	}

}
