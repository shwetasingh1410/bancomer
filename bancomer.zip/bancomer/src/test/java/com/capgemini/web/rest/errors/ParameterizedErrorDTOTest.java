package com.capgemini.web.rest.errors;

import static org.junit.Assert.*;
import java.util.Arrays;
import org.junit.Test;
import com.capgemini.web.rest.errors.ParameterizedErrorDTO;

public class ParameterizedErrorDTOTest {

	@Test
	public void testGetMessage() {
		ParameterizedErrorDTO parameterizedErrorDTO=new ParameterizedErrorDTO("message","params");
		assertEquals("message",parameterizedErrorDTO.getMessage());

	}

	@Test
	public void testGetParams() {
		ParameterizedErrorDTO parameterizedErrorDTO=new ParameterizedErrorDTO("message","params");
		String str[]={"[Ljava.lang.String;@1ff8b8f"};
		assertEquals( !Arrays.equals(str, parameterizedErrorDTO.getParams()),true);

	}
	
}
