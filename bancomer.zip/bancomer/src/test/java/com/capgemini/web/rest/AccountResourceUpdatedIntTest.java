package com.capgemini.web.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import javax.inject.Inject;
import javax.transaction.Transactional;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import com.capgemini.BbvaApp;
import com.capgemini.domain.PersistentToken;
import com.capgemini.domain.User;
import com.capgemini.repository.PersistentTokenRepository;
import com.capgemini.repository.UserRepository;
import com.capgemini.security.AuthoritiesConstants;
import com.capgemini.security.SecurityUtils;
import com.capgemini.service.MailService;
import com.capgemini.service.UserService;
import com.capgemini.web.rest.dto.KeyAndPasswordDTO;
import com.capgemini.web.rest.dto.ManagedUserDTO;
import com.capgemini.web.rest.dto.UserDTO;
import jodd.util.URLDecoder;

/**
 * Test class for the AccountResource REST controller.
 *
 * @see UserService
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = BbvaApp.class)
@WebAppConfiguration
@IntegrationTest
public class AccountResourceUpdatedIntTest {
	@InjectMocks
	private AccountResource accountresource;

	@Inject
	private UserRepository userRepository;

	@Inject
	private UserService userService;

	@Mock
	private UserService mockUserService;

	@Mock
	private MailService mockMailService;

	private MockMvc restUserMockMvc;

	private MockMvc restMvc;
	@Inject
	private PersistentTokenRepository persistentTokenRepository;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		doNothing().when(mockMailService).sendActivationEmail((User) anyObject(), anyString());
		AccountResource accountResource = new AccountResource();
		ReflectionTestUtils.setField(accountResource, "userRepository", userRepository);
		ReflectionTestUtils.setField(accountResource, "userService", userService);
		ReflectionTestUtils.setField(accountResource, "mailService", mockMailService);
		ReflectionTestUtils.setField(accountResource, "persistentTokenRepository", persistentTokenRepository);
		AccountResource accountUserMockResource = new AccountResource();
		ReflectionTestUtils.setField(accountUserMockResource, "userRepository", userRepository);
		ReflectionTestUtils.setField(accountUserMockResource, "userService", mockUserService);
		ReflectionTestUtils.setField(accountUserMockResource, "mailService", mockMailService);
		this.restMvc = MockMvcBuilders.standaloneSetup(accountResource).build();
		this.restUserMockMvc = MockMvcBuilders.standaloneSetup(accountUserMockResource).build();
	}

	@Test
	@Transactional
	public void testSaveValidLogIn() throws Exception
	{
		UserDTO validUser = new UserDTO(
				"admin",                          // login <-- invalid
				"Administrator",                  // firstName
				"Administrator",                  // lastName
				"admin@localhost",                // e-mail
				true,                             // activated
				"en",                             // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.ADMIN))
				);
		restUserMockMvc.perform(
				post("/api/account")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(validUser)));
		Optional<User> user = userRepository.findOneByEmail("admin@localhost");
		assertThat(user.isPresent()).isTrue();
	}


	@Test
	@Transactional
	public void testChangePasswordAccountSuccessful() throws Exception {

		String pwd="admin1";
		restUserMockMvc.perform(
				post("/api/account/change_password")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(pwd)))
		.andExpect(status().isOk());
	} 

	@Test
	@Transactional
	public void testChangePasswordForMinimumPasswordSize() throws Exception {
		String pwd="";
		restUserMockMvc.perform(
				post("/api/account/change_password")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(pwd)))
		.andExpect(status().isBadRequest());
	} 


	@Test
	@Transactional
	public void testChangePasswordForMaximumPasswordSize() throws Exception {

		String pwd="vZ8htg4pq0g42SS8AleWkgswgHFWWe6f33mn7gAn5FhXlXTJ8VwhZOB5l6S7aMc2FmdCrBOm6T7hHORDzdIoPai16YW5AXV47Yuop";
		restUserMockMvc.perform(
				post("/api/account/change_password")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(pwd)))
		.andExpect(status().isBadRequest());
	} 

	@Test
	@Transactional
	public void testActivateAccountSuccessful() throws Exception {

		User u= userService.createUserInformation("john", "123456", "John", "Doe", "john.doe@gmail.com", "en-US");
		String activationKey=u.getActivationKey();
		restMvc.perform(
				get("/api/activate/?key="+activationKey)
				.contentType(TestUtil.APPLICATION_JSON_UTF8))
		.andExpect(status().isOk());
	}

	@Test
	@Transactional
	public void testResetPasswordInitSuccessfulForValidEmail() throws Exception {
		User newUser = userService.createUserInformation("johndoe", "johndoe", "John", "Doe", "john.doe@localhost", "en-US");
		Optional<User> updatedUser=userRepository.findOneByLogin(newUser.getLogin());
		assertThat(updatedUser.isPresent()).isTrue();
		updatedUser.get().setActivated(true);
		userRepository.save(updatedUser.get());
		String mail="john.doe@localhost";
		restMvc.perform(
				post("/api/account/reset_password/init")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(mail))
		.andExpect(status().isOk());
		userRepository.delete(newUser);
	}

	@Test
	@Transactional
	public void testResetPasswordInitUnSuccessfulForInValidEmail() throws Exception {
		restMvc.perform(
				post("/api/account/reset_password/init")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes("john@localhost")))
		.andExpect(status().isBadRequest());

	}

	@Test
	@Transactional
	public void testResetPasswordFinishSuccessful() throws Exception {

		ManagedUserDTO newUser = new ManagedUserDTO(
				null,                   // id
				"souvikda",                  // login
				"password",             // password
				"Joe",                  // firstName
				"Shmoe",                // lastName
				"Souvik@capgemini.com",      // e-mail
				true,                   // activated
				null,               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		User u=userService.createUser(newUser);
		String resetKey=u.getResetKey();
		KeyAndPasswordDTO kp=new KeyAndPasswordDTO();
		kp.setKey(resetKey);
		kp.setNewPassword("newpassword");
		restMvc.perform(
				post("/api/account/reset_password/finish")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(kp)))
		.andExpect(status().isOk());
		userRepository.delete(u);
	}

	@Test
	@Transactional
	public void testResetPasswordFinishUnSuccessfulForInvalidPasswordLength() throws Exception {

		KeyAndPasswordDTO kp=new KeyAndPasswordDTO();
		kp.setKey("97103407104554845569");
		kp.setNewPassword(null);
		restMvc.perform(
				post("/api/account/reset_password/finish")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(kp)))
		.andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void testResetPasswordFinishUnSuccessful() throws Exception {

		KeyAndPasswordDTO kp=new KeyAndPasswordDTO();
		kp.setKey("97103407104554845569");
		kp.setNewPassword("user");
		restMvc.perform(
				post("/api/account/reset_password/finish")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(kp)))
		.andExpect(status().isInternalServerError());
	}
	@Test
	@Transactional
	public void testUpdateCurrentUserInfoSuccessfully() throws Exception
	{
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		UserDTO validUser = new UserDTO(
				"admin",          // login <-- invalid
				"Administrator1",                // upadted firstName
				"Administrator",                  // lastName
				"admin@localhost",    // e-mail
				true,                   // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.ADMIN))
				);
		restMvc.perform(
				post("/api/account")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(validUser)))
		.andExpect(status().isOk());
	}

	@Test
	@Transactional
	public void testUpdateCurrentUserInfoSuccessfulForNotExistingEmailId() throws Exception
	{
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		UserDTO validUser = new UserDTO(
				"admin",          // login <-- invalid
				"Administrator1",                // upadted firstName
				"Administrator",                  // lastName
				"admin11@localhost",    // e-mail
				true,                   // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.ADMIN))
				);
		restMvc.perform(
				post("/api/account")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(validUser)))
		.andExpect(status().isOk());
	}

	@Test
	@Transactional
	public void testGetCurrentSessionsNotSuccessful() throws Exception
	{
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		User user=new User();
		PersistentToken pt= new PersistentToken();
		user.setLogin("admin");
		user.setFirstName("Administrator");
		user.setLastName("Administrator");
		user.setEmail("admin@localhost");
		user.setActivated(true);
		user.setLangKey("en-US");
		user.setActivationKey("sadf");
		pt.setIpAddress("0:0:0:0:0:0:0:1");
		pt.setSeries("Z3Z8MDSqPei/DopfwicE5w==");
		pt.setUserAgent("Mozilla/5.0 (Doors NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.99 Safari/537.36");
		pt.setTokenDate(null);
		pt.setUser(user);        
		String expected=get("/api/account/sessions")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(user)).toString();
		assertFalse(expected==get("/api/account/sessions")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(user)).toString());
	}

	@Test
	@Transactional
	public void testGetCurrentSessionsSuccessful() throws Exception
	{

		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		String login = SecurityUtils.getCurrentUserLogin();
		assertThat(login).isEqualTo("admin");
		User admin = userRepository.findOneByLogin("admin").get();
		PersistentToken token = new PersistentToken();
		token.setSeries("1111-1111");
		token.setUser(admin);
		token.setTokenValue("1111-1111" + "-data");
		token.setTokenDate(LocalDate.now());
		token.setIpAddress("127.0.0.1");
		token.setUserAgent("Test agent");
		persistentTokenRepository.save(token);
		restMvc.perform(
				get("/api/account/sessions")
				)
		.andExpect(status().isOk());
	}


	@Test
	@Transactional
	public void testInvalidateSessionsSuccessful() throws Exception
	{

		String series="1111-1111";
		series=URLDecoder.decode(series, "UTF-8");
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		String login = SecurityUtils.getCurrentUserLogin();
		assertThat(login).isEqualTo("admin");
		User admin = userRepository.findOneByLogin("admin").get();
		PersistentToken token = new PersistentToken();
		token.setSeries("1111-1111");
		token.setUser(admin);
		token.setTokenValue("1111-1111" + "-data");
		token.setTokenDate(LocalDate.now());
		token.setIpAddress("127.0.0.1");
		token.setUserAgent("Test agent");
		persistentTokenRepository.save(token);
		restMvc.perform(
				delete("/api/account/sessions/1111-1111"));
	}

	@Test
	@Transactional
	public void testSaveAccountWithSameEmailAndLogInDetails() throws IOException, Exception
	{
		ManagedUserDTO firstUser = new ManagedUserDTO(
				null,                   // id
				"souvik",              // login
				"password",         // password
				"Bob",              // firstName
				"Green",            // lastName
				"souvik@localhost",          // e-mail <-- invalid
				true,               // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		User u1=userService.createUser(firstUser);
		ManagedUserDTO secondUser = new ManagedUserDTO(
				null,                   // id
				"souvik93",              // login
				"password",         // password
				"Bob",              // firstName
				"Green",            // lastName
				"souvik93@localhost",          // e-mail <-- invalid
				true,               // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		User u2=userService.createUser(secondUser);
		ManagedUserDTO updatedUser = new ManagedUserDTO(
				null,                   // id
				"souvik93",              // login
				"password",         // password
				"Bob",              // firstName
				"Green",            // lastName
				"souvik@localhost",          // e-mail <-- invalid
				true,               // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		restMvc.perform(
				post("/api/account")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(updatedUser)))
		.andExpect(status().isBadRequest());
		userRepository.delete(u1);
		userRepository.delete(u2);
	}

}
