package com.capgemini.web.rest;

import com.capgemini.BbvaApp;
import com.capgemini.repository.UserRepository;
import com.capgemini.service.UserService;
import com.capgemini.web.rest.UserResource;
import com.capgemini.domain.User;
import com.capgemini.repository.AuthorityRepository;
import com.capgemini.security.AuthoritiesConstants;
import com.capgemini.service.MailService;
import com.capgemini.web.rest.dto.ManagedUserDTO;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import javax.inject.Inject;
import javax.transaction.Transactional;
import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
/**
 * Test class for the UserResource REST controller.
 *
 * @see UserResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = BbvaApp.class)
@WebAppConfiguration
@IntegrationTest
public class UsersResourceUpdatedIntTest {

	@InjectMocks
	private UserResource userResource;

	@Inject
	private UserRepository userRepository;

	@Inject
	private UserService userService;

	@Inject
	private AuthorityRepository authorityRepository;

	@Inject
	private PageableHandlerMethodArgumentResolver pageableArgumentResolver;

	private MockMvc restUserMockMvc;

	@Mock
	private MailService mockMailService;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		ReflectionTestUtils.setField(userResource, "userRepository", userRepository);
		ReflectionTestUtils.setField(userResource, "userService", userService);
		ReflectionTestUtils.setField(userResource, "authorityRepository", authorityRepository);
		this.restUserMockMvc = MockMvcBuilders.standaloneSetup(userResource)
				.setCustomArgumentResolvers(pageableArgumentResolver).build();
	}


	@Test
	@Transactional
	public void testGetAllUsersSuccessfully() throws Exception
	{
		restUserMockMvc
		.perform(get("/api/users")
				.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(content().contentType("application/json"));
	}

	@Test
	public void testGetLoggedInUsersSuccessfully() throws Exception
	{
		restUserMockMvc.perform(get("/api/users/system")
				.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(content().contentType("application/json"))
		.andExpect(jsonPath("$.lastName").value("System"));
	}

	@Test
	public void testGetLoggedInUsersforunknownUsers() throws Exception
	{
		restUserMockMvc.perform(get("/api/users/souvik")
				.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isNotFound());

	}

	@Test
	@Transactional
	public void testCreateUserSuccessful() throws Exception {
		ManagedUserDTO validUser = new ManagedUserDTO(
				null,                   // id
				"joe",                  // login
				"password",             // password
				"Joe",                  // firstName
				"Shmoe",                // lastName
				"joe@example.com",      // e-mail
				true,                   // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		restUserMockMvc.perform(
				post("/api/users")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(validUser)))
		.andExpect(status().isCreated());
	}

	@Test
	@Transactional
	public void testUserCreationFailedIfSameLogInAlreadyExixst() throws Exception {
		ManagedUserDTO validUser = new ManagedUserDTO(
				null,                   // id
				"admin",                  // login
				"password",             // password
				"Joe",                  // firstName
				"Shmoe",                // lastName
				"joe@example.com",      // e-mail
				true,                   // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		restUserMockMvc.perform(
				post("/api/users")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(validUser)))
		.andExpect(status().isBadRequest());

	}

	@Test
	@Transactional
	public void testUserCreationFailedIfSameEmailIdAlreadyExixst() throws Exception {
		ManagedUserDTO validUser = new ManagedUserDTO(
				null,                   // id
				"joe",                  // login
				"password",             // password
				"Joe",                  // firstName
				"Shmoe",                // lastName
				"admin@localhost",      // e-mail
				true,                   // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);

		restUserMockMvc.perform(
				post("/api/users")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(validUser)))
		.andExpect(status().isBadRequest());

	}

	@Test
	public void testUserDeletedSuccessfully() throws Exception
	{             restUserMockMvc.perform(delete("/api/users/user")
			.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(content().string(""));
	}

	@Test
	@Transactional
	public void testUserUpdatedSuccessfully() throws Exception
	{
		ManagedUserDTO newUser = new ManagedUserDTO(
				null,                   // id
				"joe",                  // login
				"password",             // password
				"Joe",                  // firstName
				"Shmoe",                // lastName
				"joe@example.com",      // e-mail
				true,                   // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		User user=userService.createUser(newUser);
		ManagedUserDTO updatedUser = new ManagedUserDTO(
				user.getId(),                   // id
				"joe",                  // login
				"password",             // password
				"John",                  // firstName
				"Doe",                // lastName
				"joe@example.com",      // e-mail
				true,                   // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		restUserMockMvc.perform(
				put("/api/users")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(updatedUser)));
		Optional<User> u = userRepository.findOneById(user.getId());
		assertThat(u.get().getFirstName()).isEqualTo("John");
		assertThat(u.get().getLastName()).isEqualTo("Doe");
	}

	@Test
	@Transactional
	public void testUserUpdatedSuccessfullyForNonExistingEmailId() throws Exception
	{
		ManagedUserDTO updatedUser = new ManagedUserDTO(
				null,                   // id
				"joe",                  // login
				"password",             // password
				"John",                  // firstName
				"Doe",                // lastName
				"joedoee@example.com",      // e-mail
				true,                   // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		restUserMockMvc.perform(
				put("/api/users")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(updatedUser)));
	}

	@Test
	@Transactional
	public void testUserUpdatedUnSuccessfulForSameEmailId() throws Exception
	{
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		Optional<User> maybeUser = userRepository.findOneById((long) 3);
		assertThat(maybeUser.isPresent()).isTrue();
		Set<String> ha=new HashSet<String>();
		ha.add(AuthoritiesConstants.ADMIN);
		ManagedUserDTO user1 = new ManagedUserDTO(
				null,                      // id
				"souvik",                       // login
				"password",                       // password
				"Souvik",             // firstName
				"Das",               // lastName
				"souvik@localhost",            // e-mail
				true,                          // activated
				"en",                          // langKey
				ha,
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		ManagedUserDTO user2 = new ManagedUserDTO(
				null,                      // id
				"souvikda",                       // login
				"password",                       // password
				"Souv",             // firstName
				"Das",               // lastName
				"souvikda@localhost",            // e-mail
				true,                          // activated
				"en",                          // langKey
				ha,
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		userService.createUser(user1);
		userService.createUser(user2);
		ManagedUserDTO updateUser = new ManagedUserDTO(
				null,                      // id
				"souvikda",                       // login
				"password",                       // password
				"Souv",             // firstName
				"Das",               // lastName
				"souvik@localhost",            // e-mail
				true,                          // activated
				"en",                          // langKey
				ha,
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		restUserMockMvc.perform(
				put("/api/users")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(updateUser)))
		.andExpect(status().isBadRequest());
	}

	@Test
	@Transactional
	public void testUserUpdatedUnSuccessfulforSameLogIn() throws Exception
	{
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		Optional<User> maybeUser = userRepository.findOneById((long) 3);
		assertThat(maybeUser.isPresent()).isTrue();
		Set<String> ha=new HashSet<String>();
		ha.add(AuthoritiesConstants.ADMIN);
		ManagedUserDTO user1 = new ManagedUserDTO(
				null,                      // id
				"souvik",                       // login
				"password",                       // password
				"Souvik",             // firstName
				"Das",               // lastName
				"souvik@localhost",            // e-mail
				true,                          // activated
				"en",                          // langKey
				ha,
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		ManagedUserDTO user2 = new ManagedUserDTO(
				null,                      // id
				"souvikda",                       // login
				"password",                       // password
				"Souv",             // firstName
				"Das",               // lastName
				"souvikda@localhost",            // e-mail
				true,                          // activated
				"en",                          // langKey
				ha,
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		User u1=userService.createUser(user1);
		User u2=userService.createUser(user2);
		ManagedUserDTO updateUser = new ManagedUserDTO(
				u2.getId(),                      // id
				"souvik",                       // login
				"password",                       // password
				"Souv",             // firstName
				"Das",               // lastName
				"souvikda@localhost",            // e-mail
				true,                          // activated
				"en",                          // langKey
				ha,
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		restUserMockMvc.perform(
				put("/api/users")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(updateUser)))
		.andExpect(status().isBadRequest());
		userRepository.delete(u1);
		userRepository.delete(u2);

	}

}
