package com.capgemini.web.rest;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import javax.inject.Inject;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import com.capgemini.BbvaApp;
import com.capgemini.web.rest.LogsResource;
import com.capgemini.web.rest.dto.LoggerDTO;


/**
 * Test class for the LogResourceREST controller.
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = BbvaApp.class)
@WebAppConfiguration
@IntegrationTest
public class LogsResourceIntTest {
	@Inject
	private LogsResource logsResource;

	private MockMvc restLogMockMvc;

	@Before
	public void setup()
	{			MockitoAnnotations.initMocks(this);
	this.restLogMockMvc = MockMvcBuilders.standaloneSetup(logsResource).build();
	}

	@Test 
	public void testGetLogsResourceList() throws Exception {    
		restLogMockMvc.perform(get("/management/jhipster/logs")
				.accept(MediaType.APPLICATION_JSON))
		.andExpect(status().isOk())
		.andExpect(content().contentType("application/json"));
	}

	@Test
	public void tsetGetLogsResourceListForPut() throws Exception
	{
		LoggerDTO lDTO =  new LoggerDTO();
		lDTO.setName("admin");
		lDTO.setLevel("A");
		restLogMockMvc.perform(
				put("/management/jhipster/logs")
				.contentType(TestUtil.APPLICATION_JSON_UTF8)
				.content(TestUtil.convertObjectToJsonBytes(lDTO)))
		.andExpect(status().isNoContent());
	}
}
