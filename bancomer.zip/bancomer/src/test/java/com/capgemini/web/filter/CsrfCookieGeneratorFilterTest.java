package com.capgemini.web.filter;

import static org.mockito.Mockito.mock;
import java.io.IOException;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import com.capgemini.web.filter.CsrfCookieGeneratorFilter;

public class CsrfCookieGeneratorFilterTest {

	@Test
	public void testDoFilterInternal() throws ServletException, IOException {
		CsrfCookieGeneratorFilter csrfCookieGeneratorFilter=new CsrfCookieGeneratorFilter();
		MockHttpServletRequest request = new MockHttpServletRequest();
		request.addParameter("parameterName", "someValue");
		FilterChain filterChain=mock(FilterChain.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		org.springframework.security.web.csrf.CsrfToken ct=mock(org.springframework.security.web.csrf.CsrfToken.class);
		request.setAttribute("_csrf",ct);
		csrfCookieGeneratorFilter.doFilterInternal(request,response,filterChain);
	}

}
