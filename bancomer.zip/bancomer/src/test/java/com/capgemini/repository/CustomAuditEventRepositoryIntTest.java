package com.capgemini.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.inject.Inject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.actuate.audit.AuditEvent;
import org.springframework.boot.actuate.audit.AuditEventRepository;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.BbvaApp;
import com.capgemini.domain.PersistentAuditEvent;
import com.capgemini.repository.PersistenceAuditEventRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = BbvaApp.class)
@WebAppConfiguration
@IntegrationTest
@Transactional
public class CustomAuditEventRepositoryIntTest {

	@Inject
	private PersistenceAuditEventRepository persistenceAuditEventRepository;

	@Inject
	private AuditEventRepository auditEventRepository;

	ZoneId defaultZoneId = ZoneId.systemDefault();
	private static final String SAMPLE_PRINCIPAL = "SAMPLE_PRINCIPAL";
	private static final String SAMPLE_TYPE = "SAMPLE_TYPE";
	private static final LocalDateTime SAMPLE_TIMESTAMP = LocalDateTime.parse("2016-12-24T10:11:30");

	@Test
	public void testFindPrincipalAndDateAreNull() throws ParseException
	{
		PersistentAuditEvent auditEvent= new PersistentAuditEvent();
		auditEvent.setAuditEventType(SAMPLE_TYPE);
		auditEvent.setPrincipal(SAMPLE_PRINCIPAL);
		auditEvent.setAuditEventDate(SAMPLE_TIMESTAMP);
		persistenceAuditEventRepository.save(auditEvent);
		PersistentAuditEvent auditEvent1= new PersistentAuditEvent();
		auditEvent1.setAuditEventType(SAMPLE_TYPE);
		auditEvent1.setPrincipal(SAMPLE_PRINCIPAL);
		auditEvent1.setAuditEventDate(SAMPLE_TIMESTAMP);
		persistenceAuditEventRepository.save(auditEvent1);
		List<AuditEvent> auditEventList=auditEventRepository.find(null, null);
		assertThat(auditEventList.isEmpty()).isFalse();

	}

	@Test
	public void testFindWhenDateISNull() throws ParseException
	{
		PersistentAuditEvent auditEvent= new PersistentAuditEvent();
		auditEvent.setAuditEventType(SAMPLE_TYPE);
		auditEvent.setPrincipal(SAMPLE_PRINCIPAL);
		auditEvent.setAuditEventDate(SAMPLE_TIMESTAMP);
		persistenceAuditEventRepository.save(auditEvent);
		List<AuditEvent> auditEventList=auditEventRepository.find(SAMPLE_PRINCIPAL, null);
		assertThat(auditEventList.isEmpty()).isFalse();
	}

	@Test
	public void testFind() throws ParseException,DateTimeException
	{
		PersistentAuditEvent auditEvent= new PersistentAuditEvent();
		auditEvent.setAuditEventType(SAMPLE_TYPE);
		auditEvent.setPrincipal(SAMPLE_PRINCIPAL);
		auditEvent.setAuditEventDate(SAMPLE_TIMESTAMP);
		persistenceAuditEventRepository.save(auditEvent);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date myDate = dateFormat.parse("25/12/2016");
		List<AuditEvent> auditEventList=auditEventRepository.find(SAMPLE_PRINCIPAL,myDate);           
		assertThat(auditEventList.isEmpty()).isTrue();
	}

	@Test
	public void testFindWhenPrincipalIsNull() throws ParseException,DateTimeException
	{
		PersistentAuditEvent auditEvent= new PersistentAuditEvent();
		auditEvent.setAuditEventType(SAMPLE_TYPE);
		auditEvent.setPrincipal(SAMPLE_PRINCIPAL);
		auditEvent.setAuditEventDate(SAMPLE_TIMESTAMP);
		persistenceAuditEventRepository.save(auditEvent);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date myDate = dateFormat.parse("25/12/2016");
		List<AuditEvent> auditEventList=auditEventRepository.find(null,myDate);           
		assertThat(auditEventList.isEmpty()).isTrue();
	}

	@Test
	@Transactional
	public void testAddSuccessful()
	{
		Map<String,Object> ma=new HashMap<String,Object>();
		AuditEvent event=new AuditEvent(new Date(),SAMPLE_PRINCIPAL,"",ma);
		auditEventRepository.add(event);
	}

	@Test
	@Transactional
	public void testAddSuccessfulWithAuthorizationAndAnonymousValue()
	{
		Map<String,Object> ma=new HashMap<String,Object>();
		AuditEvent event=new AuditEvent(new Date(),"AUTHORIZATION_FAILURE","anonymoususer",ma);
		auditEventRepository.add(event);
	}

	@Test
	@Transactional
	public void testAddSuccessfulWithAuthorizationValue()
	{
		Map<String,Object> ma=new HashMap<String,Object>();
		AuditEvent event=new AuditEvent(new Date(),"AUTHORIZATION_FAILURE","",ma);
		auditEventRepository.add(event);
	}

	@Test
	@Transactional
	public void testAddSuccessfulWithAnonymousValue()
	{
		Map<String,Object> ma=new HashMap<String,Object>();
		AuditEvent event=new AuditEvent(new Date(),"","anonymoususer",ma);
		auditEventRepository.add(event);
	}
}
