package com.capgemini.config;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.aop.logging.LoggingAspect;

public class LoggingAspectConfigTest {

	@Test
	public void test() {
		LoggingAspectConfiguration loggingAspectConfiguration= new LoggingAspectConfiguration();
		LoggingAspect loggingAspect=new LoggingAspect();
	}
}
