package com.capgemini.config;

import static org.junit.Assert.*;
import org.junit.Test;
import com.capgemini.config.JHipsterProperties.Cache;
import com.capgemini.config.JHipsterProperties.Mail;
import com.capgemini.config.JHipsterProperties.Cache.Ehcache;
import com.capgemini.config.JHipsterProperties.Http;
import com.capgemini.config.JHipsterProperties.Logging;
import com.capgemini.config.JHipsterProperties.Logging.Logstash;
import com.capgemini.config.JHipsterProperties.Metrics.Graphite;
import com.capgemini.config.JHipsterProperties.Metrics.Logs;
import com.capgemini.config.JHipsterProperties.Metrics.Spark;
import com.capgemini.config.JHipsterProperties.Ribbon;
import com.capgemini.config.JHipsterProperties.Swagger;

public class JhipsterPropertiesTest {

	@Test
	public void setTimeToLiveInDays() {
		Cache cache =new Cache();
		cache.setTimeToLiveSeconds(1461);
		assertTrue(cache.getTimeToLiveSeconds()==1461);
	}

	@Test
	public void setMaxBytesLocalHeap() {
		Ehcache ehcache= new Ehcache();
		ehcache.setMaxBytesLocalHeap("16M");
		assertTrue(ehcache.getMaxBytesLocalHeap()=="16M");
	}

	@Test
	public void setFrom() {
		Mail mail =new Mail();
		mail.setFrom("<%=baseName%>@localhost");
		assertTrue(mail.getFrom()=="<%=baseName%>@localhost");
	}

	@Test
	public void setEnabled(){
		Spark spark=new Spark();
		spark.setEnabled(false);
		assertTrue(spark.isEnabled()==false);
	}

	@Test
	public void setHost(){
		Spark spark=new Spark();
		spark.setHost("localhost");
		assertTrue(spark.getHost()== "localhost");
	}

	@Test
	public void setPort(){
		Spark spark=new Spark();
		spark.setPort(9999);
		assertTrue(spark.getPort()==9999);
	}


	@Test
	public void setPrefix(){
		Graphite graphite=new Graphite();
		graphite.setPrefix("<%=baseName%>");
		assertTrue(graphite.getPrefix()=="<%=baseName%>");
	}

	@Test
	public void setReportFrequency(){
		Logs logs=new Logs();
		logs.setReportFrequency(60);
		assertTrue(logs.getReportFrequency()==60);
	}

	@Test
	public void setQueueSize(){
		Logstash logstash=new Logstash();
		logstash.setQueueSize(512);
		assertTrue(logstash.getQueueSize()==512);
	}

	@Test
	public void setDisplayOnActiveProfiles(){
		Ribbon ribbon=new Ribbon();
		String [] rib=new String[2];
		rib[0]="dev";
		rib[1]="user";
		ribbon.setDisplayOnActiveProfiles(rib);
		assertTrue(ribbon.getDisplayOnActiveProfiles().length==2);
	}

	@Test
	public void setTimeToLiveInDaysHttp() {
		Http http=new Http();
		http.getCache().setTimeToLiveInDays(1461);
		assertTrue(http.getCache().getTimeToLiveInDays()==1461);
	}

	@Test
	public void setEnabledLogstash(){

		Logstash logstash=new Logstash();
		logstash.setEnabled(false);
		assertTrue(logstash.isEnabled()==false);
	}
	@Test
	public void setHostLogstash(){
		Logstash logstash=new Logstash();
		logstash.setHost("localhost");
		assertTrue(logstash.getHost()== "localhost");
	}

	@Test
	public void setPortLogstash(){
		Logstash logstash=new Logstash();
		logstash.setPort(5000);
		assertTrue(logstash.getPort()==5000);
	}
	
	@Test
	public void setEnabledLogging(){
		Logging logging=new Logging();
		logging.getLogstash().setEnabled(false);
		assertTrue(logging.getLogstash().isEnabled()==false);
	}
	
	@Test
	public void setHostLogging(){
		Logging logging=new Logging();
		logging.getLogstash().setHost("localhost");
		assertTrue(logging.getLogstash().getHost()== "localhost");

	}

	@Test
	public void setPortLogging(){
		Logging logging=new Logging();
		logging.getLogstash().setPort(5000);
		assertTrue(logging.getLogstash().getPort()==5000);

	}

	@Test
	public void setEnabledSwagger(){
		Swagger swagger=new Swagger();
		swagger.setEnabled(false);
		assertTrue(swagger.isEnabled()==false);
	}
	
	@Test
	public void setEnabledGraphite(){
		Graphite graphite=new Graphite();
		graphite.setEnabled(false);
		assertTrue(graphite.isEnabled()==false);
	}
	
	@Test
	public void setPortGraphite(){
		Graphite graphite=new Graphite();
		graphite.setPort(2003);
		assertTrue(graphite.getPort()==2003);
	}
	
	@Test
	public void setHostGraphite(){
		Graphite graphite=new Graphite();
		graphite.setHost("localhost");
		assertTrue(graphite.getHost()=="localhost");
	}

	@Test
	public void setEnabledLogs(){
		Logs logs=new Logs();
		logs.setEnabled(false);
		assertTrue(logs.isEnabled()==false);
	}

	@Test
	public void getMailCorshttpTest()
	{
		JHipsterProperties  jhipsterProperties =new  JHipsterProperties();
		jhipsterProperties.getCors();
		jhipsterProperties.getHttp();
		jhipsterProperties.getMail();
	}
	
	@Test
	public void setterTestOfGraphite(){
		
		Graphite gp=new Graphite();
		gp.setEnabled(true);
		gp.setHost("abc");
		gp.setPort(8080);
		assertEquals(gp.getPort(),8080);
		assertEquals(gp.getHost(),"abc");
		assertTrue(gp.isEnabled());
		
	}
	@Test
	public void setEnabledForLogs(){
		Logs logs=new Logs();
		logs.setEnabled(true);
		assertTrue(logs.isEnabled());
	}
	
	@Test
	public void seterTestForLogstash(){
		Logstash logstash=new Logstash();
		logstash.setEnabled(true);
		logstash.setHost("abc");
		logstash.setPort(8080);
		assertEquals(logstash.getPort(),8080);
		assertEquals(logstash.getHost(),"abc");
		assertTrue(logstash.isEnabled());
	}
	@Test
	public void setterTestForSwaggeAndCacher(){
		JHipsterProperties jp=new JHipsterProperties();;
		jp.getCors();
		Swagger swagger=new Swagger();
		swagger.setEnabled(true);
		com.capgemini.config.JHipsterProperties.Http.Cache cache=new com.capgemini.config.JHipsterProperties.Http.Cache();
		Http http=new Http();
		http.getCache();
		jp.getHttp();
		jp.getMail();
		cache.setTimeToLiveInDays(24);
		assertEquals(cache.getTimeToLiveInDays(),24);
		assertTrue(swagger.isEnabled());
	}


}
