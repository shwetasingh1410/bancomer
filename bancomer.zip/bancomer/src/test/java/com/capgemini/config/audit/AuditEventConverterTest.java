package com.capgemini.config.audit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.springframework.security.web.authentication.WebAuthenticationDetails;

import com.capgemini.domain.PersistentAuditEvent;

public class AuditEventConverterTest {
	AuditEventConverter aec=new  AuditEventConverter();
	@Test
	public void testConvertToAuditListWherePersistentAuditEventIsNull()
	{
		Iterable<PersistentAuditEvent> pae=null;
		assertThat(aec.convertToAuditEvent(pae)).isEmpty();
	}
	@Test
	public void testConvertDataToObjectsSuccessful()
	{
		Map<String, String> data=new HashMap<String,String>();
		data.put("1", "data1");
		data.put("2", "data2");
		aec.convertDataToObjects(data);
	}
	@Test
	public void testConvertDataToObjectsWhenDataIsNull()
	{
		aec.convertDataToObjects(null);
	}
	@Test
	public void testConvertDataToStrings()
	{
		Map<String, Object> data=new HashMap<String,Object>();
		data.put("1", new Object());
		aec.convertDataToStrings(data);
	}
	@Test
	public void testConvertDataToStringsForNullObject()
	{
		Map<String, Object> data=new HashMap<String,Object>();
		data.put("1", null);
		aec.convertDataToStrings(data);
	}
	@Test
	public void testConvertDataToStringsWithWebAuthenticationDetailsObject()
	{
		Map<String, Object> data=new HashMap<String,Object>();
		HttpServletRequest request = mock(HttpServletRequest.class); 
		data.put("1",new WebAuthenticationDetails(request));
		aec.convertDataToStrings(data);
	}
	@Test
	public void testConvertDataToStringsWhenDataIsNull()
	{
		aec.convertDataToStrings(null);
	}

}

