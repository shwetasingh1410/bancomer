package com.capgemini.config.locale;

import static org.mockito.Mockito.mock;
import javax.servlet.http.HttpServletRequest;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletResponse;
import com.capgemini.config.locale.AngularCookieLocaleResolver;

public class AngularCookieLocaleResolverTest{
	AngularCookieLocaleResolver angularCookieLocaleResolver=new AngularCookieLocaleResolver();

	@Test
	public void testResolveLocaleContext() {
		HttpServletRequest request = mock(HttpServletRequest.class); 
		angularCookieLocaleResolver. resolveLocaleContext(request);
	}

	@Test
	public void testaddCookie() {
		MockHttpServletResponse response = new MockHttpServletResponse();
		response.addHeader("parameterName", "someValue");
		angularCookieLocaleResolver. addCookie(response,"cookieValue");
	}
	
	@Test
	public void testResolveLocale()
	{
		HttpServletRequest request = mock(HttpServletRequest.class); 
		angularCookieLocaleResolver.resolveLocale(request);			
	}

}
