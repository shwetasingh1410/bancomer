package com.capgemini.service;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.time.LocalDateTime;

import java.util.Optional;

import javax.inject.Inject;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.actuate.audit.AuditEvent;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.BbvaApp;
import com.capgemini.domain.PersistentAuditEvent;
import com.capgemini.repository.PersistenceAuditEventRepository;
import com.capgemini.service.AuditEventService;

/**
 * Test class for the AuditEvent Service Class.
 *
 * @see AuditEventService
 */

@RunWith(SpringJUnit4ClassRunner.class)

@SpringApplicationConfiguration(classes = BbvaApp.class)
@WebAppConfiguration
@IntegrationTest
@Transactional
public class AuditEventServiceIntTest {

	private static final String SAMPLE_PRINCIPAL = "SAMPLE_PRINCIPAL";
	private static final String SAMPLE_TYPE = "SAMPLE_TYPE";
	private static final LocalDateTime SAMPLE_TIMESTAMP = LocalDateTime.parse("2015-08-04T10:11:30");

	private static final LocalDateTime SAMPLE_TIMESTAMPFrom = LocalDateTime.parse("2015-08-03T10:11:30");
	private static final LocalDateTime SAMPLE_TIMESTAMPTo = LocalDateTime.parse("2015-08-05T10:11:30");

	@Inject
	private AuditEventService auditEventService;

	@Inject
	private PersistenceAuditEventRepository auditEventRepository;

	@Test
	public void testFindAuditUsingIdSuccessful()
	{
		PersistentAuditEvent auditEvent= new PersistentAuditEvent();
		auditEvent.setAuditEventType(SAMPLE_TYPE);
		auditEvent.setPrincipal(SAMPLE_PRINCIPAL);
		auditEvent.setAuditEventDate(SAMPLE_TIMESTAMP);
		auditEventRepository.save(auditEvent);
		Optional<AuditEvent> aEvent=auditEventService.find(auditEvent.getId());
		assertThat(aEvent.isPresent()).isTrue();
	}

	@Test
	public void testFindAuditUsingIdUnSuccessful()
	{
		Optional<AuditEvent> aEvent=auditEventService.find((long)7);
		assertThat(aEvent.isPresent()).isFalse();
	}

	@Test
	public void testFindAuditUsingDateSuccessful()
	{
		PersistentAuditEvent auditEvent= new PersistentAuditEvent();
		auditEvent.setAuditEventType(SAMPLE_TYPE);
		auditEvent.setPrincipal(SAMPLE_PRINCIPAL);
		auditEvent.setAuditEventDate(SAMPLE_TIMESTAMP);
		auditEventRepository.save(auditEvent);
		LocalDate fromDate=SAMPLE_TIMESTAMPFrom.toLocalDate();
		LocalDate toDate=SAMPLE_TIMESTAMPTo.toLocalDate();
		Pageable pageable=null;
		Page<AuditEvent> aEvent=auditEventService.findByDates(fromDate.atTime(0,0), toDate.atTime(23, 59), pageable);
		assertThat(aEvent.hasContent()).isTrue();
	}

	@Test
	public void testFindAuditUsingDateUnSuccessful()
	{
		LocalDate fromDate=SAMPLE_TIMESTAMPFrom.toLocalDate();
		LocalDate toDate=SAMPLE_TIMESTAMPTo.toLocalDate();
		Pageable pageable=null;
		Page<AuditEvent> aEvent=auditEventService.findByDates(fromDate.atTime(0,0), toDate.atTime(23, 59), pageable);
		assertThat(aEvent.hasContent()).isFalse();
	}

	@Test
	public void testFindAllAudit()
	{
		PersistentAuditEvent auditEvent= new PersistentAuditEvent();
		auditEvent.setAuditEventType(SAMPLE_TYPE);
		auditEvent.setPrincipal(SAMPLE_PRINCIPAL);
		auditEvent.setAuditEventDate(SAMPLE_TIMESTAMP);
		auditEventRepository.save(auditEvent);
		Pageable pageable=null;
		Page<AuditEvent> aEvent=auditEventService.findAll(pageable);
		assertThat(aEvent.hasContent()).isTrue();
	}

	@Test
	public void testFindAllAuditUnSuccessful()
	{
		Pageable pageable=null;
		Page<AuditEvent> aEvent=auditEventService.findAll(pageable);
		assertThat(aEvent.hasContent()).isTrue();
	}
}
