package com.capgemini.service;

import com.capgemini.BbvaApp;
import com.capgemini.domain.User;
import com.capgemini.repository.UserRepository;
import com.capgemini.security.AuthoritiesConstants;
import com.capgemini.service.UserService;
import com.capgemini.web.rest.dto.ManagedUserDTO;
import java.time.ZonedDateTime;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import javax.inject.Inject;
import java.util.Optional;
import java.util.Arrays;
import java.util.HashSet;
import static org.assertj.core.api.Assertions.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

/**
 * Test class for the UserResource REST controller.
 *
 * @see UserService
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = BbvaApp.class)
@WebAppConfiguration
@IntegrationTest
@Transactional
public class UserServiceUpdatedIntTest {

	@Inject
	private UserRepository userRepository;

	@Inject
	private UserService userService;

	@Test
	public void testUserCreationSuccessful()
	{
		User newUser = userService.createUserInformation("johndoe", "johndoe", "John", "Doe", "john.doe@localhost", "en-US");
		Optional<User> updatedUser=userRepository.findOneByLogin(newUser.getLogin());
		assertThat(updatedUser.isPresent()).isTrue();
		userRepository.delete(newUser);
	}

	@Test
	public void testUserDeletionSuccessful()
	{
		userService.createUserInformation("johndoe", "johndoe", "John", "Doe", "john.doe@localhost", "en-US");
		userService.deleteUserInformation("johndoe");
		Optional<User> users=userRepository.findOneByLogin("johndoe");
		assertThat(users.isPresent()).isFalse();
	}

	@Test
	@Transactional
	public void testGetUserWithAuthoritiesByLoginSuccessful()
	{
		Optional<User> user=userService.getUserWithAuthoritiesByLogin("user");
		assertThat(user.isPresent()).isTrue();
	}

	@Test
	@Transactional
	public void testGetUserWithAuthoritiesByLoginUnSuccessful()
	{
		Optional<User> user=userService.getUserWithAuthoritiesByLogin("unknownLogin");
		assertThat(user.isPresent()).isFalse();
	}

	@Test
	@Transactional
	public void testGetUserWithAuthoritiesSuccessful()
	{
		User user=userService.getUserWithAuthorities((long) 3);
		assertNotNull(user);

	}

	@Test
	public void testCreateUserSuccessful()
	{
		ManagedUserDTO newUser = new ManagedUserDTO(
				null,                   // id
				"john",                  // login
				"password",             // password
				"John",                  // firstName
				"Shmoe",                // lastName
				"joe@example.com",      // e-mail
				true,                   // activated
				"en",               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		User u=userService.createUser(newUser);
		Optional<User> createdUser=userRepository.findOneByLogin(newUser.getLogin());
		assertThat(createdUser.isPresent()).isTrue();
		assertThat(createdUser.get().getLangKey()).isEqualTo("en");
		userRepository.delete(u);
	}

	@Test
	public void testCreateUserSuccessfulWithNullValueInAuthorities()
	{
		ManagedUserDTO newUser = new ManagedUserDTO(
				null,                   // id
				"john",                  // login
				"password",             // password
				"John",                  // firstName
				"Shmoe",                // lastName
				"joe@example.com",      // e-mail
				true,                   // activated
				"en",               // langKey
				null,
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		User u=userService.createUser(newUser);
		Optional<User> createdUser=userRepository.findOneByLogin(newUser.getLogin());
		assertThat(createdUser.isPresent()).isTrue();
		assertThat(createdUser.get().getLangKey()).isEqualTo("en");
		userRepository.delete(u);
	}


	@Test
	public void testCreateUserSuccessfulifLangKeyIsNull()
	{
		ManagedUserDTO newUser = new ManagedUserDTO(
				null,                   // id
				"joe",                  // login
				"password",             // password
				"Joe",                  // firstName
				"Shmoe",                // lastName
				"joe@example.com",      // e-mail
				true,                   // activated
				null,               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		userService.createUser(newUser);
		Optional<User> createdUser=userRepository.findOneByLogin(newUser.getLogin());
		assertThat(createdUser.isPresent()).isTrue();
	}

	@Test
	@Transactional
	public void testActivateRegistrationSuccessful()
	{
		User user = userService.createUserInformation("johndoe", "johndoe", "John", "Doe", "john.doe@localhost", "en-US");
		String activationKey=user.getActivationKey();
		Optional<User> activatedUser=userService.activateRegistration(activationKey);
		assertThat(activatedUser.get().getActivated()).isEqualTo(true);	
	}

	@Test
	@Transactional
	public void testActivateRegistrationUnSuccessful()
	{
		userService.createUserInformation("johndoe", "johndoe", "John", "Doe", "john.doe@localhost", "en-US");
		String inValidctivationKey="1234567891234567";
		Optional<User> activatedUser=userService.activateRegistration(inValidctivationKey);
		assertThat(activatedUser.isPresent());	
	}

	@Test
	@Transactional
	public void testGetUserWithAuthorities()
	{
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("admin", "admin"));
		SecurityContextHolder.setContext(securityContext);
		User user=userService.getUserWithAuthorities();
		assertNotNull(user);
	}

	@Test
	@Transactional
	public void testGetUserWithAuthoritiesUnSuccessful()
	{

		User user=userService.getUserWithAuthorities();
		assertNull(user);
	}


	@Test
	public void testChangePassword()
	{

		ManagedUserDTO newMUser = new ManagedUserDTO(
				null,                   // id
				"joe",                  // login
				"password",             // password
				"Joe",                  // firstName
				"Shmoe",                // lastName
				"joe@example.com",      // e-mail
				true,                   // activated
				null,               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				null,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		User newMUser1=userService.createUser(newMUser);
		SecurityContext securityContext = SecurityContextHolder.createEmptyContext();
		securityContext.setAuthentication(new UsernamePasswordAuthenticationToken("joe", "password"));
		SecurityContextHolder.setContext(securityContext);
		userService.changePassword("svbk");
		userRepository.delete(newMUser1);
	}

	@Test
	public void testRemoveActivatedUsersSuccessful() throws Exception
	{
		ZonedDateTime dateTime = ZonedDateTime.parse("2007-12-03T10:15:30+01:00[Europe/Paris]");
		ManagedUserDTO newMUser1 = new ManagedUserDTO(
				null,                   // id
				"joe",                  // login
				"password",             // password
				"Joe",                  // firstName
				"Shmoe",                // lastName
				"joe@example.com",      // e-mail
				false,                   // activated
				null,               // langKey
				new HashSet<>(Arrays.asList(AuthoritiesConstants.USER)),
				dateTime,                   // createdDate
				null,                   // lastModifiedBy
				null                    // lastModifiedDate
				);
		User u1=userService.createUser(newMUser1);
		u1.setCreatedDate(dateTime);
		u1.setActivated(false);
		userRepository.save(u1);
		userService.removeNotActivatedUsers();
	}
}
