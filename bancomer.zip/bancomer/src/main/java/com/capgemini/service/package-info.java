/**
 * Service layer beans.
 */
package com.capgemini.service;
