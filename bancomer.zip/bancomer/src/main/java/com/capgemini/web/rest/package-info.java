/**
 * Spring MVC REST controllers.
 */
package com.capgemini.web.rest;
