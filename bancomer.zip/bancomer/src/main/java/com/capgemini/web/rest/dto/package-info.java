/**
 * Data Transfer Objects used by Spring MVC REST controllers.
 */
package com.capgemini.web.rest.dto;
