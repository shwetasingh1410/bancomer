/**
 * JPA domain objects.
 */
package com.capgemini.domain;
