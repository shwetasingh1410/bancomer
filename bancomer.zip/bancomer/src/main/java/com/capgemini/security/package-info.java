/**
 * Spring Security configuration.
 */
package com.capgemini.security;
