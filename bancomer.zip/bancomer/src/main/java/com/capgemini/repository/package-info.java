/**
 * Spring Data JPA repositories.
 */
package com.capgemini.repository;
