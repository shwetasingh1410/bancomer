/**
 * Async helpers.
 */
package com.capgemini.async;
