/**
 * Spring Framework configuration files.
 */
package com.capgemini.config;
