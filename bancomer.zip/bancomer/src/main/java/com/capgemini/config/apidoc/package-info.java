/**
 * Swagger api specific code.
 */
package com.capgemini.config.apidoc;