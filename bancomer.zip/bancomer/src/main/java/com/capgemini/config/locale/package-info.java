/**
 * Locale specific code.
 */
package com.capgemini.config.locale;
