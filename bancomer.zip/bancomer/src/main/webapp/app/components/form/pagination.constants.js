(function() {
    'use strict';

    angular
        .module('bbvaApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
